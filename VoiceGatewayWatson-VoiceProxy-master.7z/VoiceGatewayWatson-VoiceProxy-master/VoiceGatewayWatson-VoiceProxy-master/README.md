# VoiceGatewayWatson-VoiceProxy
Python based Voice Proxy for integrating Voice Gateway for Watson, Watson Conversation Service and a clients backend APIs
