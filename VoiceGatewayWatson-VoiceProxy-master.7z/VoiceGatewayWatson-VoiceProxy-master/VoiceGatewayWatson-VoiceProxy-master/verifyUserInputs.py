def verifyUserInputs(message):
    
    return message        
